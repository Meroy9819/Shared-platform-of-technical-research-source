from django.contrib import admin
from .models import Notification_report_comment
# Register your models here.
admin.site.register(Notification_report_comment)