from django.contrib import admin
from .models import VisitExpertHistory,VisitResourceHistory
admin.site.register(VisitExpertHistory)
admin.site.register(VisitResourceHistory)
# Register your models here.
