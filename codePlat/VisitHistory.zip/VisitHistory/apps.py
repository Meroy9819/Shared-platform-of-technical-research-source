from django.apps import AppConfig


class VisithistoryConfig(AppConfig):
    name = 'VisitHistory'
